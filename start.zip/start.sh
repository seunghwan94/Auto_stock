#!/bin/bash

cd /home/ubuntu/StockAuto
source venv/bin/activate

# 기존 프로세스 종료
pkill -f start.py
sleep 2

# 환경변수 유지하고 백그라운드 실행
nohup env \
  ENV=$ENV \
  LIVE_MODE=$LIVE_MODE \
  UPBIT_ACCESS_KEY=$UPBIT_ACCESS_KEY \
  UPBIT_SECRET_KEY=$UPBIT_SECRET_KEY \
  DISCORD_WEBHOOK_URL=$DISCORD_WEBHOOK_URL \
  python3 start.py > logs/start.log 2>&1 &
